﻿using Microsoft.EntityFrameworkCore;
using API_Trabalho.Data;
using API_Trabalho.Model;
using API_Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class ProdutoRepositorio : IProdutoRepositorio
    {
        private readonly SistemasUsuarioDbContext DbContext;

        public ProdutoRepositorio(SistemasUsuarioDbContext sistemasUsuarioDbContext)
        {
            DbContext = sistemasUsuarioDbContext;
        }

        public async Task<ProdutoModel> BuscarPorId(int id)
        {
            return await DbContext.Produto.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<ProdutoModel>> BuscarTodosProdutos()
        {
            return await DbContext.Produto.ToListAsync();
        }
        public async Task<ProdutoModel> Adicionar(ProdutoModel Produto)
        {
            await DbContext.Produto.AddAsync(Produto);
            await DbContext.SaveChangesAsync();

            return Produto;
        }
        public async Task<ProdutoModel> Atualizar(ProdutoModel Produto, int id)
        {
            ProdutoModel ProdutoPorId = await BuscarPorId(id);
            if (ProdutoPorId == null)
            {
                throw new Exception($"Produto do ID: {id} nao foi encontrado");
            }
            ProdutoPorId.Nome = Produto.Nome;
            ProdutoPorId.Descricao = Produto.Descricao;
            ProdutoPorId.Preco = Produto.Preco;

            DbContext.Produto.Update(ProdutoPorId);
            await DbContext.SaveChangesAsync();
            return ProdutoPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            ProdutoModel ProdutoPorId = await BuscarPorId(id);
            if (ProdutoPorId == null)
            {
                throw new Exception("Produto nao encontrada");
            }
            DbContext.Produto.Remove(ProdutoPorId);
            await DbContext.SaveChangesAsync();

            return true;
        }
    }
}