﻿using API_Trabalho.Model;

namespace API_Trabalho.Repositorio.Interface
{
    public interface IProdutoRepositorio
    {
        Task<List<ProdutoModel>> BuscarTodosProdutos();

        Task<ProdutoModel> BuscarPorId(int id);

        Task<ProdutoModel> Adicionar(ProdutoModel Produto);

        Task<ProdutoModel> Atualizar(ProdutoModel Produto, int id);

        Task<bool> Apagar(int id);
    }
}
