﻿using API_Trabalho.Model;

namespace API_Trabalho.Repositorio.Interface
{
    public interface IPedidoProdRepositorio
    {
        Task<List<PedidosProdModel>> BuscarTodosPedidoProds();

        Task<PedidosProdModel> BuscarPorId(int id);

        Task<PedidosProdModel> Adicionar(PedidosProdModel PedidoProd);

        Task<PedidosProdModel> Atualizar(PedidosProdModel PedidoProd, int id);

        Task<bool> Apagar(int id);
    }
}
