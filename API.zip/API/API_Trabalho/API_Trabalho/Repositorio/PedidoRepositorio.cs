﻿ using API_Trabalho.Model;
using API_Trabalho.Data;
using API_Trabalho.Repositorio.Interface;
using Microsoft.EntityFrameworkCore;

namespace API_Trabalho.Repositorio
{
    public class PedidoRepositorio : IPedidoRepositorio
    {
        private readonly SistemasUsuarioDbContext DbContext;

        public PedidoRepositorio(SistemasUsuarioDbContext sistemaUsuariodbContext)
        {
            DbContext = sistemaUsuariodbContext;
        }
        public async Task<PedidoModel> BuscarPorId(int id)
        {
            return await DbContext.Pedidos.Include(x => x.UsuarioId).FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<PedidoModel>> BuscarTodosPedidos()
        {
            return await DbContext.Pedidos
                .Include(x => x.UsuarioId)
                .ToListAsync();
        }
        public async Task<PedidoModel> Adicionar(PedidoModel Pedido)
        {
            await DbContext.Pedidos.AddAsync(Pedido);
            await DbContext.SaveChangesAsync();

            return Pedido;
        }


        public async Task<bool> Apagar(int Id)
        {
            PedidoModel PedidoPorId = await BuscarPorId(Id);

            if (PedidoPorId == null)
            {
                throw new Exception($"Pedido do Id:{Id} não foi encontrado");
            }
            DbContext.Pedidos.Remove(PedidoPorId);
            await DbContext.SaveChangesAsync();

            return true;

        }

        public async Task<PedidoModel> Atualizar(PedidoModel Pedido, int Id)
        {
            PedidoModel PedidoPorId = await BuscarPorId(Id);

            if (PedidoPorId == null)
            {
                throw new Exception($"Usuário do Id: {Id} não encontrado");
            }

            PedidoPorId.UsuarioId = Pedido.UsuarioId;
            PedidoPorId.EnderecoEnt = Pedido.EnderecoEnt;

            DbContext.Pedidos.Update(PedidoPorId);
            await DbContext.SaveChangesAsync();

            return Pedido;
        }
    }
}
