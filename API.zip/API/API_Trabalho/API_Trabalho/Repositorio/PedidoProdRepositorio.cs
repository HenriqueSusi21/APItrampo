﻿using Microsoft.EntityFrameworkCore;
using API_Trabalho.Data;
using API_Trabalho.Model;
using API_Trabalho.Repositorio.Interface;
using API_Trabalho.Repositorio;

namespace API.Trabalho.Repositorio
{
    public class PedidoProdRepositorio : IPedidoProdRepositorio
    {
        private readonly SistemasUsuarioDbContext DbContext;

        public PedidoProdRepositorio(SistemasUsuarioDbContext sistemasUsuarioDbContext)
        {
            DbContext = sistemasUsuarioDbContext;
        }

        public async Task<PedidosProdModel> BuscarPorId(int id)
        {
            return await DbContext.PedidosProd.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<PedidosProdModel>> BuscarTodosPedidoProds()
        {
            return await DbContext.PedidosProd.ToListAsync();
        }
        public async Task<PedidosProdModel> Adicionar(PedidosProdModel PedidoProd)
        {
            await DbContext.PedidosProd.AddAsync(PedidoProd);
            await DbContext.SaveChangesAsync();

            return PedidoProd;
        }
        public async Task<PedidosProdModel> Atualizar(PedidosProdModel PedidoProd, int id)
        {
            PedidosProdModel PedidoProdPorId = await BuscarPorId(id);
            if (PedidoProdPorId == null)
            {
                throw new Exception($"PedidoProd do ID: {id} nao foi encontrado");
            }
            PedidoProdPorId.Id = PedidoProd.Id;
            PedidoProdPorId.ProdutoId = PedidoProd.ProdutoId;
            PedidoProdPorId.CategoriaId = PedidoProd.CategoriaId;
            PedidoProdPorId.Quantidade = PedidoProd.Quantidade;

            DbContext.PedidosProd.Update(PedidoProdPorId);
            await DbContext.SaveChangesAsync();
            return PedidoProdPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            PedidosProdModel PedidoProdPorId = await BuscarPorId(id);
            if (PedidoProdPorId == null)
            {
                throw new Exception("PedidoProd nao encontrada");
            }
            DbContext.PedidosProd.Remove(PedidoProdPorId);
            await DbContext.SaveChangesAsync();

            return true;
        }
    }
}