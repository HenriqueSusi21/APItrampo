﻿using API_Trabalho.Model;
using Microsoft.EntityFrameworkCore;
using API_Trabalho.Data.Map;

namespace API_Trabalho.Data
{
    public class SistemasUsuarioDbContext : DbContext
    {
        public SistemasUsuarioDbContext(DbContextOptions<SistemasUsuarioDbContext> options)
            : base(options)
        {
        }
        public DbSet<UsuarioModel> Usuarios { get; set; }
        public DbSet<PedidoModel> Pedidos { get; set; }
        public DbSet<CategoriaModel> Categoria { get; set; }
        public DbSet<ProdutoModel> Produto { get; set; }
        public DbSet<PedidosProdModel> PedidosProd { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new UsuarioMap());
            modelBuilder.ApplyConfiguration(new PedidoMap());
            modelBuilder.ApplyConfiguration(new CategoriaMap());
            modelBuilder.ApplyConfiguration(new ProdutoMap());
            modelBuilder.ApplyConfiguration(new PedidosProdMap());

            base.OnModelCreating(modelBuilder);
        }
    }
}
