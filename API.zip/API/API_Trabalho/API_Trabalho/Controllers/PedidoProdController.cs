﻿using API_Trabalho.Model;
using Microsoft.AspNetCore.Mvc;
using API_Trabalho.Repositorio.Interface;

namespace API_Trabalho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PedidoProdController : ControllerBase
    {
        private readonly IPedidoProdRepositorio _PedidoProdRepositorio;
        public PedidoProdController(IPedidoProdRepositorio PedidoProdRepositorio)
        {
            _PedidoProdRepositorio = PedidoProdRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<PedidosProdModel>>> BuscarTodasPedidoProds()
        {
            List<PedidosProdModel> PedidoProd = await _PedidoProdRepositorio.BuscarTodosPedidoProds();
            return Ok();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<PedidosProdModel>> BuscarPorId(int Id)
        {
            PedidosProdModel PedidoProd = await _PedidoProdRepositorio.BuscarPorId(Id);
            return Ok();
        }

        [HttpPost]

        public async Task<ActionResult<PedidosProdModel>> Adicionar([FromBody] PedidosProdModel PedidoProdModel)
        {
            PedidosProdModel PedidoProd = await _PedidoProdRepositorio.Adicionar(PedidoProdModel);
            return Ok();
        }

        [HttpPut("{id}")]

        public async Task<ActionResult<PedidosProdModel>> Atualizar(int id, [FromBody] PedidosProdModel PedidoProdModel)
        {
            PedidoProdModel.Id = id;
            PedidosProdModel PedidoProd = await _PedidoProdRepositorio.Atualizar(PedidoProdModel, id);
            return Ok();
        }

        [HttpDelete("{id}")]

        public async Task<ActionResult<PedidosProdModel>> Apagar(int id)
        {
            bool apagado = await _PedidoProdRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
