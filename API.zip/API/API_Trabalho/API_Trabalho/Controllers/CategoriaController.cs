﻿using API_Trabalho.Model;
using Microsoft.AspNetCore.Mvc;
using API_Trabalho.Repositorio.Interface;

namespace API_Trabalho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriaController : ControllerBase
    {
        private readonly ICategoriaRepositorio _categoriaRepositorio;
        public CategoriaController(ICategoriaRepositorio categoriaRepositorio)
        {
            _categoriaRepositorio = categoriaRepositorio;
        }

        [HttpGet]
        public async Task<ActionResult<List<CategoriaModel>>> BuscarTodasCategorias()
        {
            List<CategoriaModel> categoria = await _categoriaRepositorio.BuscarTodasCategorias();
            return Ok();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<CategoriaModel>> BuscarPorId(int Id)
        {
            CategoriaModel categoria = await _categoriaRepositorio.BuscarPorId(Id);
            return Ok();
        }

        [HttpPost]

        public async Task<ActionResult<CategoriaModel>> Adicionar([FromBody] CategoriaModel categoriaModel)
        {
            CategoriaModel categoria = await _categoriaRepositorio.Adicionar(categoriaModel);
            return Ok();
        }

        [HttpPut("{id}")]

        public async Task<ActionResult<CategoriaModel>> Atualizar(int id, [FromBody] CategoriaModel CategoriaModel)
        {
            CategoriaModel.Id = id;
            CategoriaModel categoria = await _categoriaRepositorio.Atualizar(CategoriaModel, id);
            return Ok();
        }

        [HttpDelete("{id}")]

        public async Task<ActionResult<CategoriaModel>> Apagar(int id)
        {
            bool apagado = await _categoriaRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
