﻿using API_Trabalho.Enums;

namespace API_Trabalho.Model
{
    public class CategoriaModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public StatusCate Status { get; set; }

    }
}
