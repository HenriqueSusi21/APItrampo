﻿namespace API_Trabalho.Model
{
    public class UsuarioModel
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public DateOnly DataNasc {  get; set; }
    }
}
